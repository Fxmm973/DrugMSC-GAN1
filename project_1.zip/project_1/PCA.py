import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from rdkit import Chem
from rdkit.Chem import AllChem
from mpl_toolkits.mplot3d import Axes3D  # 导入 3D 绘图工具
import pandas as pd
def get_morgan_fingerprints(mols, radius=2, n_bits=2048):
    """
    从 RDKit 分子对象列表中提取 Morgan 指纹。
    """
    fingerprints = []
    for mol in mols:
        if mol is not None:
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            fingerprints.append(fp)
    return np.array(fingerprints)

def visualize_fcd_3d(real_features, generated_features):
    """
    三维可视化生成分子和真实分子的特征分布。
    """
    # 合并特征
    features = np.vstack([real_features, generated_features])
    labels = ["Real"] * len(real_features) + ["Generated"] * len(generated_features)

    # 使用 PCA 降维到 3D
    pca = PCA(n_components=3)
    reduced_features = pca.fit_transform(features)

    # 创建 3D 图形
    fig = plt.figure(figsize=(10, 8), dpi=300)  # 提高分辨率
    ax = fig.add_subplot(111, projection='3d')

    # 绘制散点图
    for label in ["Real", "Generated"]:
        idx = [i for i, l in enumerate(labels) if l == label]
        ax.scatter(
            reduced_features[idx, 0],  # X 轴
            reduced_features[idx, 1],  # Y 轴
            reduced_features[idx, 2],  # Z 轴
            label=label,
            alpha=0.8,  # 提高透明度
            s=100  # 增大点的大小
        )

    # 设置图形属性
    ax.set_title("3D FCD Visualization: Real vs Generated Molecules", fontsize=14)
    ax.set_xlabel("PCA Component 1", fontsize=12)
    ax.set_ylabel("PCA Component 2", fontsize=12)
    ax.set_zlabel("PCA Component 3", fontsize=12)
    ax.grid(True, linestyle='--', alpha=0.5)  # 添加网格线
    ax.legend(fontsize=12)  # 设置图例字体大小

    # 保存高质量图像
    plt.savefig("fcd_3d_visualization.png", dpi=300, bbox_inches='tight')
    plt.show()

smiles=pd.read_csv('../smiles_list.csv')['SMILES']
vaild_smiles=[]
for smile in smiles:
    mol = Chem.MolFromSmiles(str(smile))  # 将 SMILES 转换为分子对象
    if mol is not None:  # 如果转换成功
        vaild_smiles.append(smile)

# 生成分子和真实分子的 SMILES 列表
generated_smiles = vaild_smiles  # 示例生成的分子
real_smiles = pd.read_csv('../real_smiles.csv')['smiles']
# 将 SMILES 转换为分子对象
real_mols = [Chem.MolFromSmiles(s) for s in real_smiles]
generated_mols = [Chem.MolFromSmiles(s) for s in generated_smiles]

# 提取 Morgan 指纹
real_features = get_morgan_fingerprints(real_mols)
generated_features = get_morgan_fingerprints(generated_mols)

# 三维可视化特征分布
visualize_fcd_3d(real_features, generated_features)

