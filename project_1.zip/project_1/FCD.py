import numpy as np
from scipy.linalg import sqrtm
from rdkit import Chem
from rdkit.Chem import AllChem
import pandas as pd

def smiles_to_mol(smiles_list):
    """
    Convert a list of SMILES strings to RDKit molecule objects.

    Parameters:
        smiles_list (list): List containing SMILES strings.

    Returns:
        list: List of RDKit molecule objects.
    """
    return [Chem.MolFromSmiles(s) for s in smiles_list]

def get_morgan_fingerprints(mols, radius=2, n_bits=2048):
    """
    Generate Morgan fingerprints from a list of RDKit molecule objects.

    Parameters:
        mols (list): List of RDKit molecule objects.
        radius (int): Radius for Morgan fingerprint generation.
        n_bits (int): Number of bits in the fingerprint.

    Returns:
        np.ndarray: Matrix of molecular fingerprints with shape (n_mols, n_bits).
    """
    fingerprints = []
    for mol in mols:
        if mol is not None:
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            fingerprints.append(fp)
    return np.array(fingerprints)

def calculate_fcd(real_features, generated_features):
    """
    Calculate the Fréchet ChemNet Distance (FCD) between two sets of molecular features.

    Parameters:
        real_features (np.ndarray): Feature matrix of real molecules.
        generated_features (np.ndarray): Feature matrix of generated molecules.

    Returns:
        float: FCD score.
    """
    # Calculate means and covariance matrices
    mu_real, sigma_real = np.mean(real_features, axis=0), np.cov(real_features, rowvar=False)
    mu_gen, sigma_gen = np.mean(generated_features, axis=0), np.cov(generated_features, rowvar=False)

    # Calculate Fréchet Distance components
    diff = mu_real - mu_gen
    covmean = sqrtm(sigma_real.dot(sigma_gen))
    if np.iscomplexobj(covmean):
        covmean = covmean.real  # Ensure the result is real-valued

    fcd = np.sum(diff**2) + np.trace(sigma_real + sigma_gen - 2 * covmean)
    return fcd

# Load SMILES data
smiles = pd.read_csv('../smiles_list.csv')['SMILES']

# Filter valid SMILES (those that can be converted to molecules)
vaild_smiles = []
for smile in smiles:
    mol = Chem.MolFromSmiles(str(smile))
    if mol is not None:
        vaild_smiles.append(smile)

# Use the valid SMILES as generated molecules for this example
# (In practice, these would come from your generative model)
generated_smiles = vaild_smiles

# Load real/reference SMILES
real_smiles = pd.read_csv('../real_smiles.csv')['smiles']

# Convert SMILES to molecule objects
real_mols = smiles_to_mol(real_smiles)
generated_mols = smiles_to_mol(generated_smiles)

# Generate Morgan fingerprints for both sets
real_features = get_morgan_fingerprints(real_mols)
generated_features = get_morgan_fingerprints(generated_mols)

# Calculate and print FCD score
fcd_score = calculate_fcd(real_features, generated_features)
print(f"Fréchet ChemNet Distance (FCD): {fcd_score}")