import matplotlib.pyplot as plt
import seaborn as sns
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
import pandas as pd

# ================== Custom Styling Parameters ==================
plt.style.use('seaborn')  # Use seaborn style
COLORS = ['#4C72B0', '#55A868', '#C44E52']  # Blue, green, red color scheme
FONT_SIZE = 12  # Global font size
DPI = 300  # Output resolution


# ===============================================================

def calculate_scaffold_metrics(train_smiles, generated_smiles):
    """Calculate Scaffold diversity, novelty and coverage metrics.

    Parameters:
        train_smiles (list): List of training set SMILES strings
        generated_smiles (list): List of generated SMILES strings

    Returns:
        dict: Dictionary containing three metrics:
            - Diversity: Ratio of unique scaffolds to total molecules
            - Novelty: Percentage of scaffolds not seen in training set
            - Coverage: Percentage of training set scaffolds covered
    """

    def get_scaffold_set(smiles_list):
        """Convert SMILES list to set of Murcko scaffolds"""
        scaffolds = set()
        for smiles in smiles_list:
            mol = Chem.MolFromSmiles(smiles)
            if mol is not None:
                scaffold = MurckoScaffold.GetScaffoldForMol(mol)
                scaffolds.add(Chem.MolToSmiles(scaffold))
        return scaffolds

    # Get scaffold sets for both datasets
    train_scaffolds = get_scaffold_set(train_smiles)
    generated_scaffolds = get_scaffold_set(generated_smiles)

    # Calculate metrics
    diversity = len(generated_scaffolds) / len(generated_smiles) if generated_smiles else 0
    novelty = len(generated_scaffolds - train_scaffolds) / len(generated_scaffolds) if generated_scaffolds else 0
    coverage = len(generated_scaffolds & train_scaffolds) / len(train_scaffolds) if train_scaffolds else 0

    return {
        "Diversity": diversity,
        "Novelty": novelty,
        "Coverage": coverage,
    }


# Load and filter SMILES data
smiles = pd.read_csv('../smiles_list.csv')['SMILES']
valid_smiles = []
for smile in smiles:
    mol = Chem.MolFromSmiles(str(smile))  # Convert SMILES to molecule object
    if mol is not None:  # Only keep valid molecules
        valid_smiles.append(smile)

# Define generated and reference molecules
# (In practice, generated_smiles would come from your model)
generated_smiles = valid_smiles
real_smiles = pd.read_csv('../real_smiles.csv')['smiles']

# Calculate scaffold metrics
metrics = calculate_scaffold_metrics(real_smiles, generated_smiles)

# ================== Visualization ==================
plt.figure(figsize=(10, 6))
bars = plt.bar(
    metrics.keys(),
    metrics.values(),
    color=COLORS,
    edgecolor='black',  # Add black borders
    linewidth=1.5,  # Border line width
    alpha=0.9,  # Transparency
    width=0.6  # Bar width
)

# Add value labels on top of bars
for bar in bars:
    height = bar.get_height()
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        height + 0.02,  # Slight vertical offset
        f"{height:.2f}",
        ha='center',
        va='bottom',
        fontsize=FONT_SIZE + 1,
        fontweight='bold',
        color='black'
    )

# Axis labels and title
plt.xlabel("Scaffold Metrics", fontsize=FONT_SIZE + 2, labelpad=10, fontweight='bold')
plt.ylabel("Score", fontsize=FONT_SIZE + 2, labelpad=10, fontweight='bold')
plt.title("Scaffold Metrics: Diversity, Novelty, and Coverage",
          fontsize=FONT_SIZE + 4, pad=20, fontweight='bold')

# Set axis limits
plt.ylim(0, 1.1)

# Customize tick labels
plt.xticks(fontsize=FONT_SIZE)
plt.yticks(fontsize=FONT_SIZE)

# Add grid lines
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Adjust layout
plt.tight_layout()

# Save high-quality figure
plt.savefig("scaffold_metrics.png", dpi=DPI, bbox_inches='tight')
plt.show()