from rdkit import Chem
from rdkit.Chem import Descriptors
import numpy as np
from scipy.stats import entropy
import pandas as pd
# 从 SMILES 提取分子量
def smiles_to_molecular_weights(smiles_list):
    weights = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            weights.append(Descriptors.MolWt(mol))
    return np.array(weights)
# 统一分箱并计算分布
def calculate_distributions(generated_weights, real_weights, bins=10):
    all_weights = np.concatenate([generated_weights, real_weights])
    hist_range = (np.min(all_weights), np.max(all_weights))
    p_hist, _ = np.histogram(generated_weights, bins=bins, range=hist_range)
    q_hist, _ = np.histogram(real_weights, bins=bins, range=hist_range)
    p_dist = (p_hist + 1e-9) / (np.sum(p_hist) + 1e-9 * bins)
    q_dist = (q_hist + 1e-9) / (np.sum(q_hist) + 1e-9 * bins)
    return p_dist, q_dist

smiles=pd.read_csv('../smiles_list.csv')['SMILES']
vaild_smiles=[]
for smile in smiles:
    mol = Chem.MolFromSmiles(str(smile))  # 将 SMILES 转换为分子对象
    if mol is not None:  # 如果转换成功
        vaild_smiles.append(smile)

# 生成分子和真实分子的 SMILES 列表
generated_smiles = vaild_smiles  # 示例生成的分子
real_smiles = pd.read_csv('../real_smiles.csv')['smiles']

# 提取分子量
generated_weights = smiles_to_molecular_weights(generated_smiles)
real_weights = smiles_to_molecular_weights(real_smiles)

# 计算分布
p_dist, q_dist = calculate_distributions(generated_weights, real_weights, bins=10)

# 计算 KL 散度
kl = entropy(p_dist, q_dist)
print(f"KL散度: {kl:.4f}")

import matplotlib.pyplot as plt


def plot_kl_divergence(p_dist, q_dist, kl_value, bins=10):
    # 获取分箱边界
    all_weights = np.concatenate([generated_weights, real_weights])
    bin_edges = np.linspace(np.min(all_weights), np.max(all_weights), bins + 1)

    # 创建画布
    plt.figure(figsize=(10, 6))

    # 绘制双分布直方图
    width = (bin_edges[1] - bin_edges[0]) * 0.4  # 调整柱子宽度
    plt.bar(bin_edges[:-1] - width / 2, p_dist, width=width, label='生成分布', alpha=0.7, color='skyblue')
    plt.bar(bin_edges[:-1] + width / 2, q_dist, width=width, label='真实分布', alpha=0.7, color='salmon')

    # 标注KL值
    plt.text(0.95, 0.95, f'KL散度 = {kl_value:.4f}',
             transform=plt.gca().transAxes, ha='right', va='top',
             bbox=dict(facecolor='white', alpha=0.8))

    # 添加标注
    plt.title("分子量分布对比与KL散度")
    plt.xlabel("分子量区间 (g/mol)")
    plt.ylabel("归一化概率")
    plt.xticks(bin_edges[:-1], rotation=45)
    plt.legend()
    plt.grid(linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()


# 使用之前计算的结果绘图
plot_kl_divergence(p_dist, q_dist, kl, bins=10)