import matplotlib.pyplot as plt
import seaborn as sns
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
import pandas as pd
# ================== 自定义美化参数 ==================
plt.style.use('seaborn')          # 使用 seaborn 主题
COLORS = ['#4C72B0', '#55A868', '#C44E52']  # 蓝、绿、红配色
FONT_SIZE = 12                    # 全局字体大小
DPI = 300                         # 输出分辨率
# ===================================================

def calculate_scaffold_metrics(train_smiles, generated_smiles):
    """计算 Scaffold 多样性、新颖性和覆盖率"""
    def get_scaffold_set(smiles_list):
        scaffolds = set()
        for smiles in smiles_list:
            mol = Chem.MolFromSmiles(smiles)
            if mol is not None:
                scaffold = MurckoScaffold.GetScaffoldForMol(mol)
                scaffolds.add(Chem.MolToSmiles(scaffold))
        return scaffolds

    train_scaffolds = get_scaffold_set(train_smiles)
    generated_scaffolds = get_scaffold_set(generated_smiles)

    diversity = len(generated_scaffolds) / len(generated_smiles) if generated_smiles else 0
    novelty = len(generated_scaffolds - train_scaffolds) / len(generated_scaffolds) if generated_scaffolds else 0
    coverage = len(generated_scaffolds & train_scaffolds) / len(train_scaffolds) if train_scaffolds else 0

    return {
        "Diversity": diversity,
        "Novelty": novelty,
        "Coverage": coverage,
    }

smiles=pd.read_csv('../smiles_list.csv')['SMILES']
vaild_smiles=[]
for smile in smiles:
    mol = Chem.MolFromSmiles(str(smile))  # 将 SMILES 转换为分子对象
    if mol is not None:  # 如果转换成功
        vaild_smiles.append(smile)

# 生成分子和真实分子的 SMILES 列表
generated_smiles = vaild_smiles  # 示例生成的分子
real_smiles = pd.read_csv('../real_smiles.csv')['smiles']


# 计算指标
metrics = calculate_scaffold_metrics(real_smiles, generated_smiles)

# ================== 绘图 ==================
plt.figure(figsize=(10, 6))
bars = plt.bar(
    metrics.keys(),
    metrics.values(),
    color=COLORS,
    edgecolor='black',  # 添加黑色边框
    linewidth=1.5,      # 边框线宽
    alpha=0.9,          # 透明度
    width=0.6           # 柱宽
)

# 添加数据标签
for bar in bars:
    height = bar.get_height()
    plt.text(
        bar.get_x() + bar.get_width()/2,
        height + 0.02,  # 标签位置微调
        f"{height:.2f}",
        ha='center',
        va='bottom',
        fontsize=FONT_SIZE + 1,
        fontweight='bold',
        color='black'
    )

# 设置坐标轴和标题
plt.xlabel("Scaffold Metrics", fontsize=FONT_SIZE + 2, labelpad=10, fontweight='bold')
plt.ylabel("Score", fontsize=FONT_SIZE + 2, labelpad=10, fontweight='bold')
plt.title("Scaffold Metrics: Diversity, Novelty, and Coverage",
         fontsize=FONT_SIZE + 4, pad=20, fontweight='bold')

# 调整坐标轴范围
plt.ylim(0, 1.1)

# 设置刻度标签
plt.xticks(fontsize=FONT_SIZE)
plt.yticks(fontsize=FONT_SIZE)

# 添加网格线
plt.grid(axis='y', linestyle='--', alpha=0.7)

# 优化布局
plt.tight_layout()

# 保存高清图
plt.savefig("scaffold_metrics_bar_beautified.png", dpi=DPI, bbox_inches='tight')
plt.show()
