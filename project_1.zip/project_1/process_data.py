import pandas as pd


def smiles_to_indices(input_csv, output_csv, num_samples=10000, max_length=50):
    """
    Convert SMILES strings to indexed sequences with zero-padding.

    Args:
        input_csv (str): Path to input CSV file containing SMILES strings
        output_csv (str): Path to save output CSV with indexed sequences
        num_samples (int): Number of SMILES to process (default: 10000)
        max_length (int): Maximum sequence length (default: 50)

    Steps:
        1. Define character-to-index mapping
        2. Load SMILES data from CSV
        3. Sample specified number of SMILES
        4. Convert characters to indices with padding
        5. Save sequences to CSV
    """
    # Define character vocabulary and create mapping dictionary
    all_characters = ['|', 'C', '#', '%', ')', '(', '+', '-', '/', '.', '1', '0', '3', '2', '5', '4', '7',
                      '6', '9', '8', '=', 'A', '@', 'B', 'F', 'I', 'H', 'O', 'N', 'P', 'S', '[', ']',
                      '\\', 'c', 'e', 'i', 'l', 'o', 'n', 'p', 's', 'r', '<']

    # Create character-to-index mapping
    char_to_index = {char: idx for idx, char in enumerate(all_characters)}

    # Load SMILES data from CSV
    df = pd.read_csv(input_csv,encoding='utf-16')

    # Verify required column exists
    if 'canonical_smiles' not in df.columns:
        raise ValueError("Input CSV must contain 'canonical_smiles' column")

    # Extract and sample SMILES strings
    smiles_list = df['canonical_smiles'].astype(str).tolist()
    sampled_smiles = smiles_list[:min(num_samples, len(smiles_list))]

    # Process each SMILES string
    sequences = []
    for smile in sampled_smiles:
        # Convert characters to indices
        indices = []
        for char in smile:
            if char in char_to_index:
                indices.append(char_to_index[char])
            else:
                # Handle unknown characters (skip or use special token)
                continue

        # Truncate or pad sequence
        if len(indices) > max_length:
            indices = indices[:max_length]
        else:
            indices += [0] * (max_length - len(indices))

        sequences.append(indices)

    # Create output DataFrame
    columns = [f'pos_{i}' for i in range(max_length)]
    output_df = pd.DataFrame(sequences, columns=columns)

    # Save to CSV
    output_df.to_csv(output_csv, index=False)
    print(f"Saved {len(sequences)} sequences to {output_csv}")
    print(f"Sequence length: {max_length}, Samples processed: {len(sequences)}")


# Example usage
if __name__ == "__main__":
    # Modify these paths as needed
    input_file = "chembl_34_chemreps.csv"
    output_file = "smiles_sample.csv"

    smiles_to_indices(
        input_csv=input_file,
        output_csv=output_file,
        num_samples=10000,  # Number of SMILES to process
        max_length=50  # Sequence length (with padding)
    )