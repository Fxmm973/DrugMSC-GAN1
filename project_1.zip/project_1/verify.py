import pandas as pd
from rdkit import Chem
from rdkit.Chem import Draw
from rdkit.Chem.Draw import IPythonConsole

# 1. Define index-to-character mapping (must match the generative model's vocabulary)
allowed_chars = ['|', 'C', '#', '%', ')', '(', '+', '-', '/', '.', '1', '0', '3', '2', '5', '4', '7',
                 '6', '9', '8', '=', 'A', '@', 'B', 'F', 'I', 'H', 'O', 'N', 'P', 'S', '[', ']',
                 '\\', 'c', 'e', 'i', 'l', 'o', 'n', 'p', 's', 'r', '<']


# 2. Load index data from CSV
def load_index_data(csv_path):
    """Load molecular index sequences from CSV file.

    Args:
        csv_path (str): Path to CSV file containing index sequences

    Returns:
        numpy.ndarray: Array of index sequences with shape (num_molecules, sequence_length)
    """
    df = pd.read_csv(csv_path)
    # Assumes each column represents a timestep, each row is a molecule's index sequence
    return df.values


# 3. Convert index sequence to SMILES string
def indices_to_smiles(indices, allowed_chars):
    """Convert index sequence to SMILES string.

    Args:
        indices (list/np.array): Sequence of character indices
        allowed_chars (list): List of allowed characters in vocabulary

    Returns:
        str: Generated SMILES string with padding removed
    """
    smiles = []
    for idx in indices:
        if idx == 0:  # Assuming 0 is the stop token
            break
        if idx < len(allowed_chars):
            smiles.append(allowed_chars[idx])
    # Join characters and remove padding tokens
    return ''.join(smiles).replace('<PAD>', '')


# 4. Validate SMILES using RDKit
def validate_smiles(smiles):
    """Validate and standardize SMILES string using RDKit.

    Args:
        smiles (str): Input SMILES string to validate

    Returns:
        tuple: (RDKit molecule object, standardized SMILES) or (None, error message)
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "Invalid SMILES"
    try:
        # Standardize SMILES (optional but recommended)
        standardized_smi = Chem.MolToSmiles(mol)
        return mol, standardized_smi
    except Exception as e:
        return None, f"Standardization failed: {str(e)}"


# 5. Main processing pipeline
def process_csv(csv_path, output_csv='valid_molecules.csv'):
    """Process CSV file containing molecular index sequences.

    Args:
        csv_path (str): Path to input CSV file
        output_csv (str): Path to save results (default: 'valid_molecules.csv')

    Returns:
        list: List of dictionaries containing processing results for each molecule
    """
    index_data = load_index_data(csv_path)
    results = []

    for i, indices in enumerate(index_data):
        # Convert indices to SMILES
        smi = indices_to_smiles(indices, allowed_chars)

        # Validate molecule
        mol, standardized_smi = validate_smiles(smi)

        if mol is not None:
            results.append({
                'Original_SMILES': smi,
                'Standardized_SMILES': standardized_smi,
                'Validity': 'Valid',
                'Image_Path': f'molecule_{i}.png'  # Path for saving molecule image
            })
            # Optional: Save molecule image
            # Draw.MolToFile(mol, f'molecule_{i}.png')
        else:
            results.append({
                'Original_SMILES': smi,
                'Standardized_SMILES': '',
                'Validity': 'Invalid',
                'Image_Path': ''
            })

    # Save results to CSV (commented out by default)
    # pd.DataFrame(results).to_csv(output_csv, index=False)

    valid_count = len([r for r in results if r['Validity'] == 'Valid'])
    print(f"Processing complete! Valid molecules: {valid_count}/{len(results)}")
    return results


# Example usage
if __name__ == "__main__":
    input_csv = 'data/fake.csv'  # Replace with your CSV file path
    results = process_csv(input_csv)

    # Optional: Display first few valid molecules
    valid_mols = [r for r in results if r['Validity'] == 'Valid']
    print("\nSample valid molecules:")
    for i, mol in enumerate(valid_mols[:3]):
        print(f"{i + 1}. Original: {mol['Original_SMILES']}")
        print(f"   Standardized: {mol['Standardized_SMILES']}\n")